
public class PSU {

	private int power;
	
	public PSU(int a) {
		this.power = a;
	}
	
	public int getPower() {
		return this.power;
	}
}
