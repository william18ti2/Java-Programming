
public class Storage {
	private int capacity;
	public Storage() {
	}
	
	public int getCapacity() {
		return this.capacity;
	}
}
