
public class Memory {

	private int capacity;
	
	public Memory(int a) {
		this.capacity = a;
	}
	
	public int getCapacity() {
		return this.capacity;
	}
}
