
public class SSD extends Storage{

	private int capacity;
	
	public SSD(int b) {
		this.capacity = b;
	}
	
	public int getCapacity() {
		return this.capacity;
	}
}
