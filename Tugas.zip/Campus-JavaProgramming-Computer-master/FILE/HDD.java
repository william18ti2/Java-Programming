
public class HDD extends Storage {

	private int capacity;
	
	public HDD(int b) {
		this.capacity = b;
	}
	
	public int getCapacity() {
		return this.capacity;
	}
	
}
